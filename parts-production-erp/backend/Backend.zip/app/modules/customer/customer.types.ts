export interface ICustomer {
    _id?: string,
    name: string,
    phoneNumber: string,
    address: string
}