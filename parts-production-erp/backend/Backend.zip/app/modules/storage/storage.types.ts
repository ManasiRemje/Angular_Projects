export interface IStorage {
    _id?: String,
    name: String,
    isDeleted: boolean
}