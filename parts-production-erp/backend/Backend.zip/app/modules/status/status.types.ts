export interface IStatus {
    _id?: string,
    name: string
}