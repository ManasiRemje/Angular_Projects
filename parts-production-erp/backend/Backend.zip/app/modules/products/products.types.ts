export interface IProducts {
    _id?: string,
    name: string,
    price: number,
    material: string,
    defaultDimensionsPrice: number,
    isDeleted: boolean
}