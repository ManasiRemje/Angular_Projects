export interface IRoles {
    _id?: string,
    name: string
}