export interface IFurnace {
    _id?: String,
    name: String,
    isDeleted: boolean
}