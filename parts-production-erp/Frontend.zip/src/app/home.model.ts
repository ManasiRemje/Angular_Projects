export class Home {
    // id: any;
    product: any;
    quantity: any;
    dimensions: any;


    // constructor() { }
    // constructor(id: string) { this.id = id; }
}
