import { Home } from './home.model';

describe('Home', () => {
  it('should create an instance', () => {
    expect(new Home()).toBeTruthy();
  });
});
