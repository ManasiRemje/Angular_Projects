export interface UserModel {
    userName: string;
    firstName: string;
    roles: string[];
}