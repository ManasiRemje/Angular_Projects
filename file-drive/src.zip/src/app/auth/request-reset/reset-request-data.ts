export interface IResetRequest {
    email: string;
}