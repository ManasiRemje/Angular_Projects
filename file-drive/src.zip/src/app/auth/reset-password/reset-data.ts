export interface IReset {
    _id: string,
    newPassword: string,
    confirmPassword: string
}