import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './auth/auth.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { ResetPasswordComponent } from './auth/reset-password/reset-password.component';
import { RequestResetComponent } from './auth/request-reset/request-reset.component';
import { FilesComponent } from './file-upload/files/files.component';
import { FoldersComponent } from './file-upload/folders/folders.component';
import { UserComponent } from './file-upload/user/user.component';
import { AuthGuard } from './guards/auth.guard';
import { SettingsComponent } from './file-upload/settings/settings.component';
import { UserListComponent } from './admin-dashboard/user-list/user-list.component';
import { RequestsComponent } from './admin-dashboard/requests/requests.component';
import { AdminComponent } from './admin-dashboard/admin.component';
import { RoleGuard } from './guards/role.guard';

export const RoutingComponents = [
  RequestResetComponent,
  LoginComponent,
  RegisterComponent,
  AuthComponent,
  UserComponent,
  RegisterComponent,
  ResetPasswordComponent,
  UserListComponent,
  RequestsComponent,
  AdminComponent
]

const routes: Routes = [
  { path: '', redirectTo: 'auth/login', pathMatch: 'full' },
  // {
  //   path: 'auth', component: AuthComponent, 
  //   children: [
  //     { path: 'request', component: RequestResetComponent },
  //     { path: 'login', component: LoginComponent },
  //     { path: 'register', component: RegisterComponent },
  //     { path: 'reset/:id', component: ResetPasswordComponent },
  //   ]
  // },
  
  // { path: 'admin', component: AdminComponent, 
  //   children: [
  //     { path: '', component: UserListComponent },
  //     { path: 'requests', component: RequestsComponent }
  //   ]
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
